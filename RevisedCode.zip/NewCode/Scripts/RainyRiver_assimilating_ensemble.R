#' Outline for assimilating rainy river: 
#' Run the forecasting matrices for the test period
#' The test period will then be split into two periods: one to train the linear bias correction by leading day (2000-2013) and another to test the final results (2014-2019)
#' The bias correction will be according to the knn alone (not Little Fork)
#' 
#' 
#' Note that this script takes a long time to run because at each timestep, we forecast seven days, then the next day we reinitialize and reforecast. 

  # read libraries: 
    library(nonlinearTseries)
    library(lubridate)
    library(dplyr)
    library(R2jags)
  
  # knn function: 
    source("Scripts/ensemble_forecaster.R")
  
  # read in testing and training data: 
    load("Data/manitouTest_forPub.RData")
    load("Data/manitouTrain_forPub.RData")

  # test on the flood of record for the ensemble forecaster. FOR is 75,600cfs on 06-17-2014
    test.ens<-subset(test,year(date)==2014)
    test.ens<-subset(test.ens,date>as.Date("2014-05-29"))

  # get the prediction matrix. Here, each row is a forecast, with the first m columns being observed data, and the m+1 column being the first forecast ordinate, out to a forecast length of 7 days.   
    
    # create the Takens vectors: 
      m<-3  # 3 days of streamflow embedding dim
      td<-1 # 1 day time lag
      days.precip<-10  # 7 days of past precip. Will also add one day of perfectly known QPF. 
      days.temp<-3  # 3 days of past observed daily mean temperature.
      numEns<-50
      length.forecast=7
      
      takSamp<-buildTakens(train$Qcfs, embedding.dim = m, time.lag = td)  # the training attractor for streamflow
      takPred<-buildTakens(test.ens$Qcfs, embedding.dim = m, time.lag = td)  # the testing attractor for streamflow
      
      precipTakTrain<-buildTakens(train$raim,embedding.dim=days.precip,time.lag=1)  # precip training vectors
      precipTakPred<-buildTakens(test.ens$raim, embedding.dim = days.precip, time.lag = 1)  # precip testing vectors
      
      # 1 day of QPF: 
      precipTakTrain<-cbind(precipTakTrain,c(precipTakTrain[2:length(precipTakTrain[,1]),days.precip],10))
      precipTakPred<-cbind(precipTakPred,c(precipTakPred[2:length(precipTakPred[,1]),days.precip],10))
      
      # now the temperature: 
      tempTrain<-buildTakens(train$temp, embedding.dim = days.temp, time.lag = td)
      tempTest<-buildTakens(test.ens$temp, embedding.dim = days.temp, time.lag = td)
      
      # align the vectors temporally: When days.precip is longer than the others. 
      tempTrain<-tempTrain[(days.precip-(days.temp-1)):(length(tempTrain[,1])),] 
      tempTest<-tempTest[(days.precip-(days.temp-1)):(length(tempTest[,1])),] 
      takSamp<-takSamp[(days.precip-(m-1)):(length(takSamp[,1])),] 
      takPred<-takPred[(days.precip-(m-1)):(length(takPred[,1])),] 
      
      ens.forecast<-matrix(nrow=1,ncol=12)
      for(q in 1:11){
        print(q)
        
        forecast<-c(takPred[q,]) # initialize the forecast with the takens vector
        
        pp<-c(    # day q through q+days+1 (ie one day qpf), then after 1 day qpf go with just snowmelt. 
          precipTakPred[q,],test.ens$snowmelt[(q+days.precip+1):(q+days.precip+length.forecast)]
        )
        pp<-buildTakens(pp,days.precip+1,1) # from the vector: c(observed precip, 1-day qpf, and then snowmelt in the forecast period)
        tt<-tempTest[q:(q+length.forecast),] # for building the forecast temps: perfectly known
        
        add.ens<-knn.ensemble(takSamp,forecast,precipTakTrain,pp,tt,tempTrain,length.forecast=7,numEns=numEns,numHydros = 2*m)
        
        t0<-test.ens$date[(q+days.precip-1)]
        add.ens<-cbind(rep(t0,numEns),add.ens)
        ens.forecast<-rbind(ens.forecast,add.ens)
        
      }
      
      ens.forecast<-data.frame(ens.forecast)
      ens.forecast[,1]<-as.Date(ens.forecast[,1])
      ens.forecast<-na.omit(ens.forecast)

      
      # crest 06-17-2014, assess on Day 7, Day 3, and Day 1 before the crest.
      day.crest<-as.Date("2014-06-17")
      days.before<-c(7,3,1,0)
      t0<-day.crest-days.before
      
      ens.forecastStats<-list()  # ensemble mean on day of max flow, 06-17, along with 97.5 upper quantile and 2.5 lower.
      raw.day731<-list()
      
      for(j in 1:length(t0)){
        viewCrest<-subset(ens.forecast,X1==t0[j])
        dts<-seq.Date(t0[j]-days(2),t0[j]+days(8),by="day")
        viewObs<-subset(test.ens,date%in%dts)
        plot(dts,colMeans(viewCrest[,2:12]),ylim=range(c(viewObs$Qcfs,viewCrest[,2:12])),type="l",lwd=3,col="red")
        lines(dts,viewObs$Qcfs,lwd=3)
        for(i in 1:numEns){
          lines(dts,viewCrest[i,2:12],lty=2,col="darkgray")
        }
        
        # convert to long: 
        dts<-seq.Date(t0[j],t0[j]+days(7),by="day")
        lng<-data.frame("dts"=dts,"forecast"=colMeans(viewCrest[,4:11]))
        
        # add uppers and lowers: 
        upper<-c()
        lower<-c()
        for(zed in 1:(length.forecast+1)){
          upper<-c(upper,quantile(viewCrest[,zed+m],0.975))
          lower<-c(lower,quantile(viewCrest[,zed+m],0.025))
        }
        lng$upper<-upper
        lng$lower<-lower
        
        ens.forecastStats[[j]]<-lng[1:8,]
        raw.day731[[j]]<-viewCrest[,days.before[j]+m+1]  # date column, then m=3 columns. 
        
      }
      
      save(ens.forecastStats,file="Data/ensembleSummaryStats_FOR_v3.RData")
      save(raw.day731,file="Data/RawEnsemble_Day731_FOR_v3.RData")
      
      
      
      
    