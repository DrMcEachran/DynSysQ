knn.ensemble<-function(takSamp,q.array,precipTakTrain,precipTakPred,tempTest,tempTrain,length.forecast=7,numEns,numHydros=6){
  '
  
  This function creates an ensemble forecast based on a single initialization. 
  
  INPUTS
  -------
  takSamp = takens matrix of streamflow in the training period
  q.array = takens matrix of streamflow in the testing period
  precipTakTrain = takens matrix of precip in the training period
  precipTakPred = takens matrix of precip in the testing period
  tempTest = takens matrix of temperature in the training period
  tempTrain = takens matrix of temperature in the testing period
  test = the raw test array from which to grab snowmelt.
  length.forecast = length of forecast (days)
  numEns = number of ensemble members to use 
  numHydros = k, how many nearest neighbors
  
  
  
  '

  ens<-matrix(nrow=(numEns),ncol=(m+length.forecast+1))
  
  for(rb in 1:length(ens[,1])){
    forecast<-c(q.array)
    
    for(j in m:(m+length.forecast)){
      dist<-c()
      precip.dist<-c()
      temp.dist<-c()
      for(i in 1:length(takSamp[,1])){
        dist[i]<-euc.dist(forecast[(j-(m-1)):j],takSamp[i,])
        precip.dist[i]<-euc.dist(precipTakPred[j-m+1,],precipTakTrain[i,])
        temp.dist[i]<-euc.dist(tempTest[j-m+1,],tempTrain[i,])
      }
      
      dist<-(dist-mean(dist))/sd(dist)
      precip.dist<-(precip.dist-mean(precip.dist))/sd(precip.dist)
      temp.dist<-(temp.dist-mean(temp.dist))/sd(temp.dist)
      dist<-dist+precip.dist+temp.dist
      
      kSamp<-matrix(nrow=(numHydros*3),ncol=m+1)
      pSamp<-matrix(nrow=(numHydros*3),ncol=days.precip+1)  # ** without QPF: matrix(nrow=2*m,ncol=m)

      locs<-c()
      closest.distances<-c()
      for(i in 1:length(kSamp[,1])){  # fill in the k nearest neighbors
        locs[i]<-which.min(dist[1:(length(dist)-1)])
        kSamp[i,] <- c(takSamp[locs[i],],takSamp[locs[i]+1,m])
        closest.distances[i]<-min(dist[1:(length(dist)-1)])
        dist[locs[i]]<-max(dist)+1.0
        pSamp[i,] <- precipTakTrain[locs[i],]
      }
      
      closest.distances<-abs(closest.distances)
      closest.distances=closest.distances+1  # add some arbitraty value so that we don't blow up at distance = 0 for the weight
      b=mean(closest.distances) # some value
      w=exp(-0.5*((closest.distances/b)^2))
      #w=rep(1/length(closest.distances),length(closest.distances))  # this version gives equal weight
      kSamp.locations<-seq(1,(numHydros*3))
      kSamp.choose<-resample(kSamp.locations,numHydros,w)
      
      #if(rb==1){
      #  k<-kSamp
      #  nn.pp<-pSamp
      #}else{
        #k<-matrix(kSamp[kSamp.choose,],ncol=length(kSamp[kSamp.choose,]))
        k<-kSamp[kSamp.choose,]
        nn.pp<-matrix(pSamp[kSamp.choose,],ncol=days.precip+1)
      #}
      lin.reg<-optim(par=c(1,rep(1,m)),fn=pw.knn,  method="L-BFGS-B",lower=0, hessian=F, k=k,pp=matrix(precipTakPred[j-m+1,],ncol=(days.precip+1)),nn.pp=nn.pp)
      
      # Now that our regression is defined, we want to predict the next value:
      pred.inits<-forecast[(j-(m-1)):j]
      al<-lin.reg$par[1]   #lin.reg$coefficients[1]  
      be<-lin.reg$par[2:length(lin.reg$par)]    #lin.reg$coefficients[2:6]    
      pred<-al+be%*%pred.inits
      forecast[j+1]<-pred
    }
    ens[rb,]<-forecast
    
  }
  
  # ens<-ens[,(m+1):length(ens[1,])]
  
  return(ens)
}


 